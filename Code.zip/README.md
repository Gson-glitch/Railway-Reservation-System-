<h3>1. First Install the Required libraries</h2>

<h5>This can be done by running the following command in your terminal or command prompt</h2>
<code>pip install -r requirements.txt</code>

<h3>2. Then create a folder named <code>datasets</code> in the same directory as the project files.</h2>
<h5>Copy all the CSV files into the <code>datasets</code> folder</h4>

<h3>3. Next run the following commands to load the data from the csv files into the database and create the GUI</h3>
<code>python3 main.py</code><br>
<code>python3 gui.py</code>

